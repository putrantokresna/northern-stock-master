<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex flex-row mt-3">
            <?php if($id == null): ?>
            <h3 class="title fw-bolder" style="color: #FF9029;">Tambah <span style="color: #000">Produk</span> Baru</h3>
            <?php else: ?>
            <h3 class="title fw-bolder" style="color: #FF9029;">Edit <span style="color: #000">Produk</span></h3>
            <?php endif; ?>
        </div>
        <div class="row mt-3">
            <div class="col-9">
                <div class="card shadow">
                    <div class="card-body text-white fw-bold" style="background :#1B1717">
                        <form method="post" action="<?php echo e(route('product.post')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php if($id != null): ?>
                                <input type="hidden" name="id" value="<?php echo e($id); ?>" readonly/>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col">
                                    <label for="nama" class="form-label">Nama Produk</label>
                                    <?php if($id == null): ?>
                                        <input type="text" id="nama" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-white fw-bold" name="nama"
                                            maxlength="100" value="<?php echo e(old('nama')); ?>" style="background: #FF9029; border-color: #FF9029" >
                                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php else: ?>
                                        <input type="text" id="nama" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-white fw-bold" name="nama"
                                            maxlength="100" value="<?php echo e(old('nama', $produk->nama)); ?>" style="background: #FF9029; border-color: #FF9029">
                                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col">
                                    <label for="besaran" class="form-label">Besaran</label>
                                    <?php if($id == null): ?>
                                        <input type="number" id="besaran" class="form-control  <?php $__errorArgs = ['besaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-white fw-bold" name="besaran" value="<?php echo e(old('besaran')); ?>" maxlength="100" style="background: #FF9029; border-color: #FF9029" >
                                        <?php $__errorArgs = ['besaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php else: ?>
                                        <input type="text" id="besaran" class="form-control <?php $__errorArgs = ['besaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-white fw-bold" name="besaran" maxlength="100" value="<?php echo e(old('besaran', $produk->Besaran)); ?>" style="background: #FF9029; border-color: #FF9029" >
                                        <?php $__errorArgs = ['besaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col">
                                    <label for="satuan" class="form-label">Satuan</label>
                                    <?php if($id == null): ?>
                                        <input type="text" id="satuan" class="form-control <?php $__errorArgs = ['satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-white fw-bold" name="satuan" maxlength="100" value="<?php echo e(old('satuan')); ?>" style="background: #FF9029; border-color: #FF9029" >
                                        <?php $__errorArgs = ['satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php else: ?>
                                        <input type="text" id="satuan" class="form-control <?php $__errorArgs = ['satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-white fw-bold" name="satuan" maxlength="100" value="<?php echo e(old('satuan', $produk->Satuan)); ?>" style="background: #FF9029; border-color: #FF9029" >
                                        <?php $__errorArgs = ['satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col category-wrapper">
                                    <label for="kategori" class="form-label">Kategori</label>
                                    <?php if($id == null): ?>
                                        <select class="<?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control text-white fw-bold kategori-opt" value="<?php echo e(old('kategori')); ?>" name="kategori" style="background: #FF9029; border-color: #FF9029" >
                                            <option value="">-- Pilih Kategori --</option>
                                            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                {
                                                <option value="<?php echo e($val->kategori); ?>" <?php echo e(old('kategori') == "$val->kategori" ? 'selected' : ''); ?>><?php echo e($val->kategori); ?></option>
                                                }
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php else: ?>
                                        <select class="<?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control text-white fw-bold kategori-opt" value="<?php echo e(old('kategori', $produk->kategori)); ?>" name="kategori" style="background: #FF9029; border-color: #FF9029">
                                            <option value="">-- Pilih Kategori --</option>
                                            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                {
                                                <option value="<?php echo e($val->kategori); ?>" <?php echo e(old('kategori', $produk->kategori) == "$val->kategori" ? 'selected' : ''); ?>><?php echo e($val->kategori); ?></option>
                                                }
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php endif; ?>
                                    <div id="tambah_kategori">

                                    </div>
                                    <div class="mt-2">
                                        <button type="button" class="btn btn-primary btn-sm fw-bold" id="addButton" style="background: #89B83C; border-color: #89B83C;">
                                            <i class="fas fa-plus" style="color: #fff"></i> New Category
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col">
                                    <label for="ket" class="form-label">Keterangan Masa Kadaluwarsa</label>
                                    <?php if($id == null): ?>
                                        <select name="ket" class="<?php $__errorArgs = ['ket'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control text-white fw-bold"  value="<?php echo e(old('ket')); ?>" style="background: #FF9029; border-color: #FF9029">
                                            <option value="">-- Pilih --</option>
                                            <option value="Expired Date" <?php echo e(old('ket') == "Expired Date" ? 'selected' : ''); ?>>Expired Date</option>
                                            <option value="Best Before" <?php echo e(old('ket') == "Best Before" ? 'selected' : ''); ?>>Best Before</option>
                                        </select>
                                        <?php $__errorArgs = ['ket'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php else: ?>
                                        <select name="ket" class="<?php $__errorArgs = ['ket'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control text-white fw-bold"  value="<?php echo e(old('ket', $produk->ket)); ?>" style="background: #FF9029; border-color: #FF9029">
                                            <option value="">-- Pilih --</option>
                                            <option value="Expired Date" <?php echo e(old('ket', $produk->ket) == "Expired Date" ? 'selected' : ''); ?>>Expired Date</option>
                                            <option value="Best Before" <?php echo e(old('ket', $produk->ket) == "Best Before" ? 'selected' : ''); ?>>Best Before</option>
                                        </select>
                                        <?php $__errorArgs = ['ket'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col">
                                    <?php if($id == null): ?>
                                        <label for="stok" class="form-label">Stok Awal</label>
                                        <input type="number" id="stok" name="qty_awal" min="0"
                                            class="<?php $__errorArgs = ['qty_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control text-white fw-bold" value="<?php echo e(old('qty_awal')); ?>" style="background: #FF9029; border-color: #FF9029"  />
                                            <?php $__errorArgs = ['qty_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php else: ?>
                                        <label for="stok" class="form-label">Stok Awal</label>
                                        <?php if($produk->produk_inven->count() > 0): ?>
                                            <?php if($produk->opname_detail->count() > 0): ?>
                                                <input type="number" id="stok" class="form-control text-white fw-bold"
                                                    value="<?php echo e($produk->opname_detail->last()->qty_actual); ?>" style="background: #BF6A1B; border-color: #BF6A1B" disabled />
                                            <?php else: ?>
                                                <input type="number" id="stok" class="form-control text-white fw-bold"
                                                    value="<?php echo e($produk->qty_awal); ?>" style="background: #BF6A1B; border-color: #BF6A1B" disabled />
                                            <?php endif; ?>
                                            <small class="text-secondary">Harap melakukan update stok di halaman awal atau
                                                stock opname</small>
                                        <?php else: ?>
                                            <input type="number" id="stok" name="qty_awal" min="0"
                                                class="<?php $__errorArgs = ['qty_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control text-white fw-bold" value="<?php echo e(old('qty_awal', $produk->qty_awal)); ?>" style="background: #FF9029; border-color: #FF9029"  />
                                                <?php $__errorArgs = ['qty_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col">
                                    <button type="submit" class="btn btn-primary text-white fw-bold my-2" style="background: #FF9029; border-color: #FF9029">Simpan</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>                         
        let availableTags = [];
        let kategori = <?php echo json_encode($kategori, 15, 512) ?>;
        for (var i = 0; i < kategori.length; i++)
            availableTags.push(kategori[i].kategori);
        
        let counter = 1

        $('#addButton').click(function () {
            if (counter == 1) {
                counter++;
            
                let newKategori =   `
                                            <input type="text" id="kategori" placeholder="Input New Category"
                                            autocomplete="off" class="<?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control input-category mt-3 text-white fw-bold" name="kategori" maxlength="50" style="background: #FF9029; border-color: #FF9029">
                                            <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    `
                
                $('#tambah_kategori').append(newKategori)
                
                $('.kategori-opt').hide();

                $('input.input-category').on('keyup',function() {
                    if ($(this).val() != '') {
                        console.log($(this).val())
                        $('.kategori-opt').hide();
                    } else {
                        console.log($(this).val())
                        $('.kategori-opt').show();
                    }
                });
            }
            else {
                    alert("Tidak dapat Menambahkan Kategori!");
                    return;
            }
        });

        // $('#removeButton').click(function () {
        //     if(counter == 1) {
        //             alert("Tidak dapat mengurangi Kategori!");
        //             return;
        //         }
        //         else {
        //             $("#tambah_kategori").remove();
        //             $('.kategori-opt').show();
        //             counter--;
        //         }
        // });

        $(document).ready(function() {
            // $(".basicAutoComplete").autoComplete({
            //     minLength: 1,
            //     events: {
            //         search: function(qry, callback) {
            //             let finalSearch = availableTags.filter(item => item.toLowerCase().includes(qry.toLowerCase()));
            //             callback(finalSearch);
            //         }
            //     }
            // });input#kategori
            // $('.js-example-basic-multiple').select2({
            //     placeholder: "-- Pilih Kategori --",
            //     style:"background: #FF9029; border-color: #FF9029",
            //     maximumSelectionLength: 1
            // });

            $('.kategori-opt').on('change', function() {
                //   var data = $(".select2 option:selected").text();
                if ($(this).val().length != 0) {
                    $('input.input-category').removeAttr('name');
                    $('input.input-category').hide();
                } else {
                    $('input.input-category').attr('name', 'kategori');
                    $('input.input-category').show();
                }
            });

            // $('input.input-category').on('keyup',function() {
            //     if ($(this).val() != '') {
            //         console.log($(this).val())
            //         $('.select2-container').hide();
            //     } else {
            //         console.log($(this).val())
            //         $('.select2-container').show();
            //     }
            // });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Kresna/Documents/BINUS KRESNA/FEB 2023 LULUS!!/APPS/northen-stock-master[FINAL]/resources/views/edit/product.blade.php ENDPATH**/ ?>