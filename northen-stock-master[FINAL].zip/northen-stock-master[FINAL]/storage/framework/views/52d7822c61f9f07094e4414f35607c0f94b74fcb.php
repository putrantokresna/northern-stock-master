<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if(session('errmsg') != null): ?>
            <div class="d-flex flex-row mt-3">
                <div class="alert alert-danger alert-dismissible fade show flex-fill" role="alert">
                    <?php echo e(session('errmsg')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        <?php endif; ?>
        <?php if(session('msg') != null): ?>
            <div class="d-flex flex-row mt-3">
                <div class="alert alert-success alert-dismissible fade show flex-fill" role="alert">
                    <?php echo e(session('msg')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        <?php endif; ?>
        <div class="d-flex flex-row mt-3">
            <h3>Daftar Stok</h3>
            <?php if(session('user')->role == 'Admin'): ?>
                <div class="d-flex flex-column ms-auto align-items-start">
                    <a href="<?php echo e(route('product.edit')); ?>" class="btn btn-success">Tambah Produk</a>
                </div>
                <div class="d-flex flex-column ms-2 align-items-start">
                    <a href="<?php echo e(route('product.export', ['tanggal' => $tanggal, 'kategori' => $kategori])); ?>"
                        class="btn btn-primary">Ekspor Data</a>
                </div>
            <?php else: ?>
                <div class="d-flex flex-column ms-auto align-items-start">
                    <a href="<?php echo e(route('product.export', ['tanggal' => $tanggal, 'kategori' => $kategori])); ?>"
                        class="btn btn-primary">Ekspor Data</a>
                </div>
            <?php endif; ?>
        </div>
        <div class="row mt-3">
            <div class="col">
                <div class="card shadow">
                    <div class="card-body">
                        <form method="get">
                            <div class="d-flex flex-row">
                                <div class="d-flex flex-column flex-fill">
                                    <label for="kategori" class="form-label">Kategori</label>
                                    <select id="kategori" class="form-select" name="kategori">
                                        <?php if($kategori == '' || $kategori == null): ?>
                                            <option value="" selected disabled></option>
                                        <?php else: ?>
                                            <option value="" disabled></option>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($kategori == $k->kategori): ?>
                                                <option value="<?php echo e($k->kategori); ?>" selected><?php echo e($k->kategori); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($k->kategori); ?>"><?php echo e($k->kategori); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="ms-2 d-flex flex-column flex-fill">
                                    <label for="tanggal" class="form-label">Tanggal</label>
                                    <?php if($tanggal == '' || $tanggal == null): ?>
                                        <input type="date" id="tanggal" class="form-control" name="tanggal" />
                                    <?php else: ?>
                                        <input type="date" id="tanggal" class="form-control" name="tanggal"
                                            value="<?php echo e($tanggal); ?>" />
                                    <?php endif; ?>
                                </div>
                                <div class="ms-2 d-flex flex-col flex-lg-fill align-self-end">
                                    <div class="d-flex flex-row ms-auto">
                                        <button type="submit" class="btn btn-warning">Filter</button>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive mt-3">
                                <table id="table" class="table table-bordered" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>Nomor</th>
                                            <th>Kode Produk</th>
                                            <th>Nama Produk</th>
                                            <th>Kategori</th>
                                            <th>Stok Awal / Opname</th>
                                            <th>Produk Masuk</th>
                                            <th>Produk Keluar</th>
                                            <th>Stok Akhir</th>
                                            <th>Masa Kadaluarsa</th>
                                            <?php if(session('user')->role == 'Admin'): ?>
                                                <th>Menu</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($p->id); ?></td>
                                                <td><?php echo e($p->nama); ?></td>
                                                <td><?php echo e($p->kategori); ?></td>
                                                <td><?php echo e($p->qty_awal); ?></td>
                                                <td>
                                                    <?php for($i = 0; $i < $p->produk_inven_masuk->count(); $i++): ?>
                                                        <?php echo e($p->produk_inven_masuk[$i]->jumlah); ?> pada
                                                        <?php echo e($p->produk_inven_masuk[$i]->created_at); ?>

                                                        <?php if($i < $p->produk_inven_masuk->count() - 1): ?>
                                                            <br />
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                </td>
                                                <td>
                                                    <?php for($i = 0; $i < $p->produk_inven_keluar->count(); $i++): ?>
                                                        <?php echo e($p->produk_inven_keluar[$i]->jumlah); ?> pada
                                                        <?php echo e($p->produk_inven_keluar[$i]->created_at); ?>

                                                        <?php if($i < $p->produk_inven_keluar->count() - 1): ?>
                                                            <br />
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                </td>
                                                <td><?php echo e($p->qty_akhir); ?></td>
                                                <td>
                                                    <?php for($i = 0; $i < $p->kadaluarsa->count(); $i++): ?>
                                                        <?php echo e($p->kadaluarsa[$i]->jumlah); ?> kadaluarsa pada
                                                        <?php echo e(substr($p->kadaluarsa[$i]->kadaluarsa, 0, 10)); ?> (sisa
                                                        <?php echo e($p->kadaluarsa[$i]->sisa_hari); ?> hari)
                                                        <?php if($i < $p->kadaluarsa->count() - 1): ?>
                                                            <br />
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                </td>
                                                <?php if(session('user')->role == 'Admin'): ?>
                                                    <td>
                                                        <a href="<?php echo e(route('product.edit', ['id' => $p->id])); ?>"
                                                            class="btn btn-outline-warning mt-1">Edit</a>
                                                        <!-- Button trigger modal -->
                                                        <button type="button" class="btn btn-primary"
                                                            data-bs-toggle="modal" data-bs-target="#exampleModal">
                                                            Hapus Produk
                                                        </button>

                                                        <!-- Modal -->
                                                        <div class="modal fade" id="exampleModal" tabindex="-1"
                                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                                            Modal title</h1>
                                                                        <button type="button" class="btn-clos`e"
                                                                            data-bs-dismiss="modal"
                                                                            aria-label="Close"></button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        ...
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-bs-dismiss="modal">Close</button>
                                                                        <a href="<?php echo e(route('product.delete', ['id' => $p->id])); ?>"
                                                                            class="btn btn-outline-danger mt-1">Hapus</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function() {
            let role = "<?php echo e(session('user')->role); ?>";
            if (role == 'Admin')
                $('#table').DataTable({
                    "order": [
                        [0, "asc"]
                    ],
                    "columnDefs": [{
                            "searchable": false,
                            "targets": [8]
                        },
                        {
                            "sortable": false,
                            "targets": [4, 5, 7, 8]
                        }
                    ]
                });
            else
                $('#table').DataTable({
                    "order": [
                        [0, "asc"]
                    ],
                    "columnDefs": [{
                        "sortable": false,
                        "targets": [4, 5, 7]
                    }]
                });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northen-stock-master\resources\views/product.blade.php ENDPATH**/ ?>