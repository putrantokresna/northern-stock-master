<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <table>
        <thead>
            <tr>
                <td colspan="28" style="text-align: center; font-size: 20px;"><b>LAPORAN KELUAR MASUK HARIAN</b></td>
            </tr>
            <tr>
                <td colspan="28" style="text-align: center; font-size: 15px;" value="#tanggal"></td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><b>No</b></td>
                <td><b>Kode</b></td>
                <td colspan="3"><b>Nama Produk</b></td>
                <td colspan="2"><b>Besaran</b></td>
                <td colspan="2"><b>Satuan</b></td>
                <td colspan="2"><b>Kategori</b></td>
                <td colspan="2"><b>Stok Awal</b></td>
                <td colspan="4"><b>Barang Masuk</b></td>
                <td colspan="4"><b>Barang Keluar</b></td>
                <td colspan="2"><b>Stok Akhir</b></td>
                <td colspan="4"><b>Masa Kadaluarsa</b></td>
            </tr>
            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($p->id); ?></td>
                <td colspan="3"><?php echo e($p->nama); ?></td>
                <td colspan="2"><?php echo e($p->Besaran); ?></td>
                <td colspan="2"><?php echo e($p->Satuan); ?></td>
                <td colspan="2"><?php echo e($p->kategori); ?></td>
                <td colspan="2"><?php echo e($p->qty_awal); ?></td>
                <?php
                $isMasuk = false;
                $isKeluar = false;
                ?>
                <?php $__currentLoopData = $p->produk_inven_masuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $isMasuk = true;
                    ?>
                    <td colspan="4">+ <?php echo e($pi->jumlah); ?> produk pada <?php echo e($pi->created_at); ?></td>
                    <?php break; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$isMasuk): ?>
                <td colspan="4"></td>
                <?php endif; ?>
                <?php $__currentLoopData = $p->produk_inven_keluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $isKeluar = true;
                    ?>
                    <td colspan="4">- <?php echo e($pi->jumlah); ?> produk pada <?php echo e($pi->created_at); ?></td>
                    <?php break; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$isKeluar): ?>
                <td colspan="4"></td>
                <?php endif; ?>
                <td colspan="2"><?php echo e($p->qty_akhir); ?></td>
                <?php $__currentLoopData = $p->kadaluarsa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td colspan="4"><?php echo e($k->jumlah); ?> produk kadaluarsa pada <?php echo e(substr($k->kadaluarsa, 0, 10)); ?> (sisa <?php echo e($k->sisa_hari); ?> hari)</td>
                    <?php break; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <?php
            $max = $p->produk_inven_keluar->count();
            if($max < $p->produk_inven_masuk->count())
                $max = $p->produk_inven_masuk->count();
            if($max < $p->kadaluarsa->count())
                $max = $p->kadaluarsa->count();
            ?>
            <?php for($i=1; $i<$max; $i++): ?>
                <tr>
                    <td colspan="4"></td>
                    <td colspan="4"></td>
                    <td colspan="3"></td>
                    <td colspan="2"></td>
                    <?php if($i < $p->produk_inven_masuk->count()): ?>
                    <td colspan="4">+ <?php echo e($p->produk_inven_masuk[$i]->jumlah); ?> produk pada <?php echo e($p->produk_inven_masuk[$i]->created_at); ?></td>
                    <?php else: ?>
                    <td colspan="4"></td>
                    <?php endif; ?>
                    <?php if($i < $p->produk_inven_keluar->count()): ?>
                    <td colspan="4">- <?php echo e($p->produk_inven_keluar[$i]->jumlah); ?> produk pada <?php echo e($p->produk_inven_keluar[$i]->created_at); ?></td>
                    <?php else: ?>
                    <td colspan="4"></td>
                    <?php endif; ?>
                    <td colspan="2"></td>
                    <?php if($i < $p->kadaluarsa->count()): ?>
                    <td colspan="4"><?php echo e($p->kadaluarsa[$i]->jumlah); ?> produk kadaluarsa pada <?php echo e(substr($p->kadaluarsa[$i]->kadaluarsa, 0, 10)); ?> (sisa <?php echo e($p->kadaluarsa[$i]->sisa_hari); ?> hari)</td>
                    <?php else: ?>
                    <td></td>
                    <?php endif; ?>
                </tr>
            <?php endfor; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr colspan="3" style="text-align : left"></tr>
            <tr colspan="3" style="text-align : left">
                <td colspan="2">
                    Diketahui,
                </td>
                <td></td>
                <td></td>
                <td colspan="2">
                    Disetujui,
                </td>
            </tr>
            <tr colspan="3">
                <td colspan="2"></td>
                <td></td>
                <td></td>
                <td colspan="2"></td>
            </tr>
            <tr colspan="3">
                <td colspan="2"></td>
                <td></td>
                <td></td>
                <td colspan="2"></td>
            </tr>
            <tr colspan="3">
                <td colspan="2"></td>
                <td></td>
                <td></td>
                <td colspan="2"></td>
            </tr>
            <tr colspan="3" style="text-align : left">
                <td colspan="2">Store Manager</td>
                <td></td>
                <td></td>
                <td colspan="2">Owner Resto</td>
            </tr>
        </tfoot>
    </table>
</html><?php /**PATH /Users/Kresna/Documents/BINUS KRESNA/FEB 2023 LULUS!!/APPS/northen-stock-master[FINAL]/resources/views/exports/product.blade.php ENDPATH**/ ?>