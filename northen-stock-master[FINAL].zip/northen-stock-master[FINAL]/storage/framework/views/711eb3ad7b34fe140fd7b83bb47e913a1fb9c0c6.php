<?php $__env->startSection('content'); ?>
        <div class="container-fluid">
            <?php if(session('errmsg') != null || $errmsg != null): ?>
            <div class="d-flex flex-row mt-3">
                <div class="alert alert-danger alert-dismissible fade show flex-fill" role="alert">
                    <?php echo e(session('errmsg') ?: $errmsg); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
            <?php endif; ?>
            <?php if(session('msg') != null || $msg != null): ?>
            <div class="d-flex flex-row mt-3">
                <div class="alert alert-success alert-dismissible fade show flex-fill" role="alert">
                    <?php echo e(session('msg') ?: $msg); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
            <?php endif; ?>
            <div class="d-flex flex-row mt-3">
                <h3 class="title fw-bolder" style="color: #FF9029;">Stock <span style="color: #000">Opname</span></h3>
                <?php if($opname != null): ?>
                <?php if($opname->opname_detail->count() > 0): ?>
                <div class="d-flex flex-column ms-auto align-items-start">
                <a href="<?php echo e(route('opname.export', ['tanggal' => $tanggal, 'kategori' => $kategori])); ?>" class="btn btn-primary fw-bold" style="background: #297DBB; border-color: #297DBB;">Cetak Stock Opname</a>
                </div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="row mt-3">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-body fw-bold" style="background :#1B1717">
                                <form method="get">
                                <div class="d-flex flex-row text-white fw-bold">
                                    <div class="d-flex flex-column flex-fill">
                                        <label for="kategori" class="form-label">Kategori</label>
                                        <select id="kategori" class="form-select text-white fw-bold" name="kategori" style="background: #FF9029; border-color: #FF9029">
                                            <?php if($kategori == "" || $kategori == null): ?>
                                            <option value="" selected disabled></option>
                                            <?php else: ?>
                                            <option value="" disabled></option>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($kategori == $k->kategori): ?>
                                            <option value="<?php echo e($k->kategori); ?>" selected><?php echo e($k->kategori); ?></option>
                                            <?php else: ?>
                                            <option value="<?php echo e($k->kategori); ?>"><?php echo e($k->kategori); ?></option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="ms-2 d-flex flex-column flex-fill">
                                        <label for="tanggal" class="form-label">Tanggal</label>
                                        <?php if($tanggal == "" || $tanggal == null): ?>
                                        <input type="date" id="tanggal" class="form-control text-white fw-bold" name="tanggal" style="background: #FF9029; border-color: #FF9029"/>
                                        <?php else: ?>
                                        <input type="date" id="tanggal" class="form-control text-white fw-bold" name="tanggal" value="<?php echo e($tanggal); ?>" style="background: #FF9029; border-color: #FF9029"/>
                                        <?php endif; ?>
                                    </div>
                                    <div class="ms-2 d-flex flex-col flex-lg-fill align-self-end">
                                        <div class="d-flex flex-row ms-auto">
                                            <button type="submit" class="btn btn-warning text-white fw-bold" style="background: #FF9029; border-color: #FF9029">Filter</button>
                                        </div>
                                    </div>
                                </div>
                                </form>
                                <form method="post" action="<?php echo e(route('opname.post')); ?>">
                                <?php echo csrf_field(); ?>
                                <?php if($tanggal != null): ?>
                                <input type="hidden" name="tanggal" value="<?php echo e($tanggal); ?>" />
                                <?php else: ?>
                                <input type="hidden" name="tanggal" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" />
                                <?php endif; ?>
                                <div class="table-responsive mt-3">
                                    <table id="table" class="table table-bordered" style="width:100%">
                                        <thead>
                                            <tr class="coloumn text-white" style="background: #FF9029;">
                                                <th class="no-produk text-center">No</th>
                                                <th class="kode-produk text-center">Kode</th>
                                                <th class="nama-produk text-center">Nama Produk</th>
                                                <th class="besaran-produk text-center">Besaran</th>
                                                <th class="satuan-produk text-center">Satuan</th>
                                                <th class="kategori-produk text-center">Kategori</th>
                                                <th class="stok-awal-produk text-center">Stok Awal / Opname</th>
                                                <th class="masuk-produk text-center">Produk Masuk</th>
                                                <th class="keluar-produk text-center">Produk Keluar</th>
                                                <th class="stok-akhir-produk text-center">Stok Akhir</th>
                                                <th class="stok-aktual-produk text-center">Stok Aktual</th>
                                                <th class="selisih-produk text-center">Selisih</th>
                                            </tr>
                                        </thead>
                                        <tbody style="background: #E2DFCC">
                                            <?php
                                            $continue = true;
                                            ?>
                                            <?php if($opname != null): ?>
                                            <?php if($opname->opname_detail->count() > 0): ?>
                                            <?php
                                            $continue = false;
                                            ?>

                                            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <!-- <td class="no-produk text-center"><?php echo e($loop->iteration); ?></td> -->
                                                <?php
                                                $od = $p->opname_detail->where('opname_id', $opname->id)->last();
                                                ?>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td class="id-produk text-center"><?php echo e($p->id); ?></td>
                                                <td class="nama-produk text-center"><?php echo e($p->nama); ?></td>
                                                <td class="besaran-produk text-center"><?php echo e($p->Besaran); ?></td>
                                                <td class="satuan-produk text-center"><?php echo e($p->Satuan); ?></td>
                                                <td class="kategori-produk text-center"><?php echo e($p->kategori); ?></td>
                                                <?php if($od != null): ?>
                                                <td class="qty-awal-produk-od text-center"><?php echo e($od->qty_awal); ?></td>
                                                <?php else: ?>
                                                <td class="qty-awal-produk text-center"><?php echo e($p->qty_awal); ?></td>
                                                <?php endif; ?>
                                                <td>
                                                <?php if($od != null && $od->opname_detail_produk != null): ?>
                                                <?php for($i=0;$i<$od->opname_detail_produk->count();$i++): ?>
                                                <?php if($od->opname_detail_produk[$i]->jenis == 'Masuk'): ?>
                                                <?php echo e($od->opname_detail_produk[$i]->content); ?>

                                                <br/>
                                                <?php endif; ?>
                                                <?php endfor; ?>
                                                <?php else: ?>
                                                <?php for($i=0;$i<$p->produk_inven_masuk->count();$i++): ?>
                                                <?php echo e($p->produk_inven_masuk[$i]->jumlah); ?> produk pada <?php echo e($p->produk_inven_masuk[$i]->created_at); ?>

                                                <?php if($i < $p->produk_inven_masuk->count()-1): ?>
                                                <br/>
                                                <?php endif; ?>
                                                <?php endfor; ?>
                                                </td>
                                                <?php endif; ?>
                                                <td>
                                                <?php if($od != null && $od->opname_detail_produk != null): ?>
                                                <?php for($i=0;$i<$od->opname_detail_produk->count();$i++): ?>
                                                <?php if($od->opname_detail_produk[$i]->jenis == 'Keluar'): ?>
                                                <?php echo e($od->opname_detail_produk[$i]->content); ?>

                                                <br/>
                                                <?php endif; ?>
                                                <?php endfor; ?>
                                                <?php else: ?>
                                                <?php for($i=0;$i<$p->produk_inven_keluar->count();$i++): ?>
                                                <?php echo e($p->produk_inven_keluar[$i]->jumlah); ?> produk pada <?php echo e($p->produk_inven_keluar[$i]->created_at); ?>

                                                <?php if($i < $p->produk_inven_keluar->count()-1): ?>
                                                <br/>
                                                <?php endif; ?>
                                                <?php endfor; ?>
                                                <?php endif; ?>
                                                </td>
                                                <?php if($od != null): ?>
                                                <td class="qty-system-produk-od text-center"><?php echo e($od->qty_system); ?></td>
                                                <?php else: ?>
                                                <td class="qty-akhir-produk text-center"><?php echo e($p->qty_akhir); ?></td>
                                                <?php endif; ?>
                                                <?php if($od != null): ?>
                                                <td class="qty-actual-produk text-center"><?php echo e($od->qty_actual); ?></td>
                                                <?php else: ?>
                                                <td></td>
                                                <?php endif; ?>
                                                <?php if($od != null): ?>
                                                <td class="qty-selisih-produk text-center"><?php echo e($od->qty_actual - $od->qty_system < 0 ? $od->qty_actual - $od->qty_system : abs($od->qty_actual - $od->qty_system)); ?></td>
                                                <?php else: ?>
                                                <td></td>
                                                <?php endif; ?>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <?php endif; ?>
                                            <?php endif; ?>

                                            <?php if($opname == null || $continue): ?>
                                            <?php
                                                $index = 0;
                                                $odp_contents = [];
                                                $odp_jenises = [];
                                            ?>
                                            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                array_push($odp_contents, "");
                                                array_push($odp_jenises, "");
                                            ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><input type="hidden" name="produk_id[]" value="<?php echo e($p->id); ?>"/><?php echo e($p->id); ?></td>
                                                <td><?php echo e($p->nama); ?></td>
                                                <td><?php echo e($p->Besaran); ?></td>
                                                <td><?php echo e($p->Satuan); ?></td>
                                                <td><?php echo e($p->kategori); ?></td>
                                                <td><input type="hidden" name="qty_awal[]" value="<?php echo e($p->qty_awal); ?>"/><?php echo e($p->qty_awal); ?></td>
                                                <td>
                                                <?php for($i=0;$i<$p->produk_inven_masuk->count();$i++): ?>
                                                + <?php echo e($p->produk_inven_masuk[$i]->jumlah); ?> produk pada <?php echo e($p->produk_inven_masuk[$i]->created_at); ?>

                                                <?php
                                                    $odp_contents[$index] .= $p->produk_inven_masuk[$i]->jumlah.' produk pada '.$p->produk_inven_masuk[$i]->created_at;
                                                    $odp_jenises[$index] .= 'Masuk';
                                                ?>
                                                <?php if($i < $p->produk_inven_masuk->count()-1): ?>
                                                <?php
                                                    $odp_contents[$index] .= ';';
                                                    $odp_jenises[$index] .= ';';
                                                ?>
                                                <br/>
                                                <?php else: ?>
                                                <?php
                                                    $odp_contents[$index] .= ';';
                                                    $odp_jenises[$index] .= ';';
                                                ?>
                                                <?php endif; ?>
                                                <?php endfor; ?>
                                                </td>
                                                <td>
                                                <?php for($i=0;$i<$p->produk_inven_keluar->count();$i++): ?>
                                                - <?php echo e($p->produk_inven_keluar[$i]->jumlah); ?> produk pada <?php echo e($p->produk_inven_keluar[$i]->created_at); ?>

                                                <?php
                                                    $odp_contents[$index] .= $p->produk_inven_keluar[$i]->jumlah.' produk pada '.$p->produk_inven_keluar[$i]->created_at;
                                                    $odp_jenises[$index] .= 'Keluar';
                                                ?>
                                                <?php if($i < $p->produk_inven_keluar->count()-1): ?>
                                                <?php
                                                    $odp_contents[$index] .= ';';
                                                    $odp_jenises[$index] .= ';';
                                                ?>
                                                <br/>
                                                <?php endif; ?>
                                                <?php endfor; ?>
                                                <input type="hidden" name="odp_content[]" value="<?php echo e($odp_contents[$index]); ?>"/>
                                                <input type="hidden" name="odp_jenis[]" value="<?php echo e($odp_jenises[$index]); ?>"/>
                                                </td>
                                                <td><input type="hidden" name="qty_akhir[]" value="<?php echo e($p->qty_akhir); ?>"/><?php echo e($p->qty_akhir); ?></td>
                                                <td><input type="number" min="0" name="qty_actual[]" class="form-control"/></td>
                                                <td><input type="number" readonly id="sisa" class="form-control"/></td>
                                            </tr>
                                            <?php
                                            $index++;
                                            ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php if($continue && count($produk) > 0): ?>
                                <div class="d-flex flex-col flex-lg-fill align-self-end mt-3">
                                    
                                    <button type="button" class="btn btn-primary fw-bold" data-bs-toggle="modal" data-bs-target="#exampleModal" style="background: #FF9029; border-color: #FF9029">
                                        Simpan
                                    </button>
                                    
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                        <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5 text-black" id="exampleModalLabel">Simpan Stock Opname</h1>
                                            <button type="button" class="btn-clos`e" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body text-black">
                                            Yakin sudah menginput opname dengan benar?
                                        </div>
                                        <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary text-white" data-bs-dismiss="modal" style="background: #89B83C; border-color: #89B83C;">No</button>
                                        <button type="submit" class="btn btn-success text-white" style="background: #FF533C; border-color: #FF533C">Yes</button>
                                        </div>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
        <script>
            $(function() {
                $('#table').DataTable(
                    {
                        paging: false,
                        "order": [[ 0, "asc" ]],
                        "columnDefs": [
                            { "sortable": false, "targets": [4,5,7,8] }
                        ]
                    }
                );
            });
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Kresna/Documents/BINUS KRESNA/FEB 2023 LULUS!!/APPS/northen-stock-master[FINAL]/resources/views/opname.blade.php ENDPATH**/ ?>