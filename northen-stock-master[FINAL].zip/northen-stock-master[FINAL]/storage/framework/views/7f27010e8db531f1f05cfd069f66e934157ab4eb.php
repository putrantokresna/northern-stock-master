<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <table>
        <thead>
            <tr>
                <td colspan="25" style="text-align: center; font-size: 20px;"><b>LAPORAN HASIL STOK OPNAME</b></td>
            </tr>
            <tr>
                <td colspan="25"></td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><b>No</b></td>
                <td><b>Kode</b></td>
                <td colspan="3"><b>Nama Produk</b></td>
                <td colspan="2"><b>Besaran</b></td>
                <td colspan="2"><b>Satuan</b></td>
                <td colspan="2"><b>Kategori</b></td>
                <td colspan="2"><b>Stok Awal</b></td>
                <td colspan="4"><b>Barang Masuk</b></td>
                <td colspan="4"><b>Barang Keluar</b></td>
                <td colspan="2"><b>Stok Akhir</b></td>
                <td colspan="2"><b>Stok Aktual</b></td>
                <td colspan="2"><b>Selisih</b></td>
            </tr>

            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $max = 0;
            $isOd = true;
            $od = $p->opname_detail->where('opname_id', $opname->id)->last();
            ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($p->id); ?></td>
                <td colspan="3"><?php echo e($p->nama); ?></td>
                <td colspan="2"><?php echo e($p->Besaran); ?></td>
                <td colspan="2"><?php echo e($p->Satuan); ?></td>
                <td colspan="2"><?php echo e($p->kategori); ?></td>
                <?php if($od != null): ?>
                <td colspan="2"><?php echo e($od->qty_awal); ?></td>
                <?php else: ?>
                <td colspan="2"><?php echo e($p->qty_awal); ?></td>
                <?php endif; ?>
                <td colspan="4">
                <?php if($od != null && $od->opname_detail_produk != null): ?>
                <?php
                $p->produk_inven_masuk = $od->opname_detail_produk->where('jenis', 'Masuk')->values();
                if($max < $p->produk_inven_masuk->count())
                    $max = $p->produk_inven_masuk->count();
                ?>
                <?php for($i=0;$i<$od->opname_detail_produk->count();$i++): ?>
                <?php if($od->opname_detail_produk[$i]->jenis == 'Masuk'): ?>
                <?php echo e($od->opname_detail_produk[$i]->content); ?>

                <?php break; ?>
                <?php endif; ?>
                <?php endfor; ?>
                <?php else: ?>
                <?php
                if($max < $p->produk_inven_masuk->count())
                    $max = $p->produk_inven_masuk->count();
                $isOd = false;
                ?>
                <?php for($i=0;$i<$p->produk_inven_masuk->count();$i++): ?>
                <?php echo e($p->produk_inven_masuk[$i]->jumlah); ?> pada <?php echo e($p->produk_inven_masuk[$i]->created_at); ?>

                <?php break; ?>
                <?php endfor; ?>
                </td>
                <?php endif; ?>
                <td colspan="4">
                <?php if($od != null && $od->opname_detail_produk != null): ?>
                <?php
                $p->produk_inven_keluar = $od->opname_detail_produk->where('jenis', 'Keluar')->values();
                if($max < $p->produk_inven_keluar->count())
                    $max = $p->produk_inven_keluar->count();
                ?>
                <?php for($i=0;$i<$od->opname_detail_produk->count();$i++): ?>
                <?php if($od->opname_detail_produk[$i]->jenis == 'Keluar'): ?>
                <?php echo e($od->opname_detail_produk[$i]->content); ?>

                <?php break; ?>
                <?php endif; ?>
                <?php endfor; ?>
                <?php else: ?>
                <?php
                if($max < $p->produk_inven_keluar->count())
                    $max = $p->produk_inven_keluar->count();
                ?>
                <?php for($i=0;$i<$p->produk_inven_keluar->count();$i++): ?>
                <?php echo e($p->produk_inven_keluar[$i]->jumlah); ?> pada <?php echo e($p->produk_inven_keluar[$i]->created_at); ?>

                <?php break; ?>
                <?php endfor; ?>
                <?php endif; ?>
                </td>
                <?php if($od != null): ?>
                <td colspan="2"><?php echo e($od->qty_system); ?></td>
                <?php else: ?>
                <td colspan="2"><?php echo e($p->qty_akhir); ?></td>
                <?php endif; ?>
                <?php if($od != null): ?>
                <td colspan="2"><?php echo e($od->qty_actual); ?></td>
                <?php else: ?>
                <td></td>
                <?php endif; ?>
                <?php if($od != null): ?>
                <td colspan="2"><?php echo e($od->qty_actual - $od->qty_system < 0 ? $od->qty_actual - $od->qty_system : abs($od->qty_actual - $od->qty_system)); ?></td>
                <?php else: ?>
                <td></td>
                <?php endif; ?>
            </tr>
            <?php for($i=1; $i<$max; $i++): ?>
                <tr>
                    <td></td>
                    <td></td>
                    <td colspan="3"></td>
                    <td colspan="2"></td>
                    <td colspan="2"></td>
                    <td colspan="2"></td>
                    <td colspan="2"></td>

                    <?php if($isOd): ?>
                    <?php if($i < $p->produk_inven_masuk->count()): ?>
                    <td colspan="4"><?php echo e($p->produk_inven_masuk[$i]->content); ?></td>
                    <?php else: ?>
                    <td colspan="4"></td>
                    <?php endif; ?>
                    <?php else: ?>
                    <?php if($i < $p->produk_inven_masuk->count()): ?>
                    <td colspan="4"><?php echo e($p->produk_inven_masuk[$i]->jumlah); ?> pada <?php echo e($p->produk_inven_masuk[$i]->created_at); ?></td>
                    <?php else: ?>
                    <td colspan="4"></td>
                    <?php endif; ?>
                    <?php endif; ?>

                    <?php if($isOd): ?>
                    <?php if($i < $p->produk_inven_keluar->count()): ?>
                    <td colspan="4"><?php echo e($p->produk_inven_keluar[$i]->content); ?></td>
                    <?php else: ?>
                    <td colspan="4"></td>
                    <?php endif; ?>
                    <?php else: ?>
                    <?php if($i < $p->produk_inven_keluar->count()): ?>
                    <td colspan="4"><?php echo e($p->produk_inven_keluar[$i]->jumlah); ?> pada <?php echo e($p->produk_inven_keluar[$i]->created_at); ?></td>
                    <?php else: ?>
                    <td colspan="4"></td>
                    <?php endif; ?>
                    <?php endif; ?>

                    <td colspan="2"></td>
                    <td colspan="2"></td>
                    <td colspan="2"></td>
                </tr>
            <?php endfor; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr colspan="3" style="text-align : left"></tr>
            <tr colspan="3" style="text-align : left">
                <td colspan="2">
                    Diketahui,
                </td>
                <td></td>
                <td></td>
                <td colspan="2">
                    Disetujui,
                </td>
            </tr>
            <tr colspan="3">
                <td colspan="2"></td>
                <td></td>
                <td></td>
                <td colspan="2"></td>
            </tr>
            <tr colspan="3">
                <td colspan="2"></td>
                <td></td>
                <td></td>
                <td colspan="2"></td>
            </tr>
            <tr colspan="3">
                <td colspan="2"></td>
                <td></td>
                <td></td>
                <td colspan="2"></td>
            </tr>
            <tr colspan="3" style="text-align : left">
                <td colspan="2">Store Manager</td>
                <td></td>
                <td></td>
                <td colspan="2">Owner Resto</td>
            </tr>
        </tfoot>
    </table>
</html><?php /**PATH /Users/Kresna/Documents/BINUS KRESNA/FEB 2023 LULUS!!/APPS/northen-stock-master[FINAL]/resources/views/exports/opname.blade.php ENDPATH**/ ?>