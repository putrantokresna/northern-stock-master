
        <footer class="p-2" style="width: 100%; background-color: #D3D3D3;">
            <div class="container my-auto">
            <div class="copyright text-center text-black my-auto">
                Copyright © Northern Stock 2023
            </div>
            </div>
        </footer><?php /**PATH C:\laragon\www\northen-stock-master\resources\views/templates/footer.blade.php ENDPATH**/ ?>