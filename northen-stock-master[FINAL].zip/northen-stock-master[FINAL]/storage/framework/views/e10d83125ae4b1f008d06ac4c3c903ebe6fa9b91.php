<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex flex-row mt-3">
            <?php if($id == null): ?>
                <h3>Tambah Produk Baru</h3>
            <?php else: ?>
                <h3>Edit Produk</h3>
            <?php endif; ?>
        </div>
        <div class="row mt-3">
            <div class="col">
                <div class="card shadow">
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('product.post')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php if($id != null): ?>
                                <input type="hidden" name="id" value="<?php echo e($id); ?>" />
                            <?php endif; ?>
                            <div class="row">
                                <div class="col">
                                    <label for="nama" class="form-label">Nama Produk</label>
                                    <?php if($id == null): ?>
                                        <input type="text" id="nama" class="form-control" name="nama"
                                            maxlength="100" required>
                                    <?php else: ?>
                                        <input type="text" id="nama" class="form-control" name="nama"
                                            maxlength="100" value="<?php echo e($produk->nama); ?>" required>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col category-wrapper">
                                    <label for="kategori" class="form-label">Kategori</label>
                                    <div class="select2">

                                        <select class="js-example-basic-multiple" name="kategori" multiple="multiple">
                                            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                {
                                                <option value="<?php echo e($val->kategori); ?>"><?php echo e($val->kategori); ?></option>
                                                }
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <input type="text" id="kategori" placeholder="Input New Category"
                                        autocomplete="off" class="form-control input-category mt-3" name="kategori" maxlength="50">
                                    
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col">
                                    <?php if($id == null): ?>
                                        <label for="stok" class="form-label">Stok Awal</label>
                                        <input type="number" id="stok" name="qty_awal" min="0"
                                            class="form-control" required />
                                    <?php else: ?>
                                        <label for="stok" class="form-label">Stok Awal</label>
                                        <?php if($produk->produk_inven->count() > 0): ?>
                                            <?php if($produk->opname_detail->count() > 0): ?>
                                                <input type="number" id="stok" class="form-control"
                                                    value="<?php echo e($produk->opname_detail->last()->qty_actual); ?>" disabled />
                                            <?php else: ?>
                                                <input type="number" id="stok" class="form-control"
                                                    value="<?php echo e($produk->qty_awal); ?>" disabled />
                                            <?php endif; ?>
                                            <small class="text-secondary">Harap melakukan update stok di halaman awal atau
                                                stock opname</small>
                                        <?php else: ?>
                                            <input type="number" id="stok" name="qty_awal" min="0"
                                                class="form-control" value="<?php echo e($produk->qty_awal); ?>" required />
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col">
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        let availableTags = [];
        let kategori = <?php echo json_encode($kategori, 15, 512) ?>;
        for (var i = 0; i < kategori.length; i++)
            availableTags.push(kategori[i].kategori);
        $(document).ready(function() {
            // $(".basicAutoComplete").autoComplete({
            //     minLength: 1,
            //     events: {
            //         search: function(qry, callback) {
            //             let finalSearch = availableTags.filter(item => item.toLowerCase().includes(qry.toLowerCase()));
            //             callback(finalSearch);
            //         }
            //     }
            // });input#kategori
            $('.js-example-basic-multiple').select2({
                placeholder: "Select Category",
                maximumSelectionLength: 1
            });

            $('.js-example-basic-multiple').on('change', function() {
                //   var data = $(".select2 option:selected").text();
                if ($(this).val().length != 0) {
                    $('input.input-category').removeAttr('name');
                    $('input.input-category').hide();
                } else {
                    $('input.input-category').attr('name', 'kategori');
                    $('input.input-category').show();
                }
            })

            $('input.input-category').on('keyup',function() {
                if ($(this).val() != '') {
                    console.log($(this).val())
                    $('.select2-container').hide();
                } else {
                    console.log($(this).val())
                    $('.select2-container').show();
                }
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\northen-stock-master\resources\views/edit/product.blade.php ENDPATH**/ ?>